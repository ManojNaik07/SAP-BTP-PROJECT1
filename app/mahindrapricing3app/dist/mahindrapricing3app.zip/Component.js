sap.ui.define(["sap/fe/core/AppComponent"],function(n){"use strict";return n.extend("mahindrapricing3app.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map